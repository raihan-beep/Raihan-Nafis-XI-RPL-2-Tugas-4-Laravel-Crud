<!-- resources/views/contacts/edit.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Edit Contact</title>
</head>
<body>
    <h1>Edit Contact</h1>
    <form action="{{ route('contacts.update', $contact->id) }}" method="POST">
        @csrf
        @method('PUT')

        <label>Name:</label>
        <input type="text" name="name" value="{{ $contact->name }}" required><br>

        <label>Email:</label>
        <input type="email" name="email" value="{{ $contact->email }}" required><br>

        <label>Phone:</label>
        <input type="text" name="phone" value="{{ $contact->phone }}" required><br>

        <button type="submit">Update Contact</button>
    </form>
</body>
</html>
