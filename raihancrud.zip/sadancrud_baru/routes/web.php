<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContactController;

// Home page (optional)
Route::get('/', function () {
    return view('welcome');
});

// Resource route for the ContactController (automatically creates all CRUD routes)
Route::resource( 'contacts', ContactController::class);

